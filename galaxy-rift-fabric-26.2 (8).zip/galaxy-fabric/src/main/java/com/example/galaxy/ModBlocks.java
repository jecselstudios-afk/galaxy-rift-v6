package com.example.galaxy;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;

public class ModBlocks {
	public static final ResourceKey<Block> RIFT_CORE_KEY = ResourceKey.create(Registries.BLOCK, GalaxyMod.id("rift_core"));
	public static final ResourceKey<Item> RIFT_CORE_ITEM_KEY = ResourceKey.create(Registries.ITEM, GalaxyMod.id("rift_core"));

	public static final Block RIFT_CORE = Registry.register(BuiltInRegistries.BLOCK, RIFT_CORE_KEY,
			new Block(BlockBehaviour.Properties.of()
					.mapColor(MapColor.COLOR_PURPLE)
					.strength(30.0F, 1200.0F)
					.sound(SoundType.STONE)
					.lightLevel(state -> 15)
					.setId(RIFT_CORE_KEY)));

	public static final Item RIFT_CORE_ITEM = Registry.register(BuiltInRegistries.ITEM, RIFT_CORE_ITEM_KEY,
			new BlockItem(RIFT_CORE, new Item.Properties().useBlockDescriptionPrefix().rarity(Rarity.EPIC).setId(RIFT_CORE_ITEM_KEY)));

	private static Block registerUnbreakable(String name, MapColor color, int light) {
		ResourceKey<Block> key = ResourceKey.create(Registries.BLOCK, GalaxyMod.id(name));
		ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, GalaxyMod.id(name));
		Block block = Registry.register(BuiltInRegistries.BLOCK, key, new Block(BlockBehaviour.Properties.of()
				.mapColor(color)
				.strength(-1.0F, 3600000.0F)
				.sound(SoundType.METAL)
				.lightLevel(state -> light)
				.setId(key)));
		Registry.register(BuiltInRegistries.ITEM, itemKey,
				new BlockItem(block, new Item.Properties().useBlockDescriptionPrefix().setId(itemKey)));
		return block;
	}

	// The spaceship is made of these. Strength -1 = cannot be broken in survival (like bedrock).
	public static final Block SHIP_HULL = registerUnbreakable("ship_hull", MapColor.SNOW, 0);
	public static final Block SHIP_DARK = registerUnbreakable("ship_dark", MapColor.COLOR_BLUE, 0);
	public static final Block SHIP_GLOW = registerUnbreakable("ship_glow", MapColor.COLOR_LIGHT_BLUE, 15);
	public static final Block SHIP_ENGINE = registerUnbreakable("ship_engine", MapColor.COLOR_ORANGE, 12);

	public static void init() {
		// touching this class registers everything above
	}
}
