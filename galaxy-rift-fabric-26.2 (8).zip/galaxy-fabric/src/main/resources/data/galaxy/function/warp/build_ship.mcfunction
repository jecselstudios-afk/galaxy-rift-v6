execute unless block 3 200 0 galaxy:ship_hull run function galaxy:warp/build_ship_now
fill -1 200 -1 1 200 1 galaxy:ship_hull
