execute unless entity @a[distance=..130] run return 0
scoreboard players add @s galaxy_t 1
scoreboard players operation #pm galaxy_t = @s galaxy_t
scoreboard players operation #pm galaxy_t %= #3 galaxy_t
execute if score #pm galaxy_t matches 0 run function galaxy:pship/draw
execute as @a[distance=..2.2] run function galaxy:pship/board
