scoreboard players add @s galaxy_c 1
execute if score @s galaxy_c matches 2 run tp @s 0.00 207.00 -23.00 facing 0 203 2
execute if score @s galaxy_c matches 3 run tp @s 1.17 207.13 -22.97 facing 0 203 2
execute if score @s galaxy_c matches 4 run tp @s 2.33 207.27 -22.90 facing 0 203 2
execute if score @s galaxy_c matches 5 run tp @s 3.49 207.40 -22.76 facing 0 203 2
execute if score @s galaxy_c matches 6 run tp @s 4.64 207.54 -22.58 facing 0 203 2
execute if score @s galaxy_c matches 7 run tp @s 5.79 207.67 -22.35 facing 0 203 2
execute if score @s galaxy_c matches 8 run tp @s 6.92 207.80 -22.06 facing 0 203 2
execute if score @s galaxy_c matches 9 run tp @s 8.03 207.93 -21.73 facing 0 203 2
execute if score @s galaxy_c matches 10 run tp @s 9.14 208.05 -21.34 facing 0 203 2
execute if score @s galaxy_c matches 11 run tp @s 10.22 208.18 -20.91 facing 0 203 2
execute if score @s galaxy_c matches 12 run tp @s 11.28 208.30 -20.43 facing 0 203 2
execute if score @s galaxy_c matches 13 run tp @s 12.32 208.42 -19.90 facing 0 203 2
execute if score @s galaxy_c matches 14 run tp @s 13.34 208.54 -19.32 facing 0 203 2
execute if score @s galaxy_c matches 15 run tp @s 14.32 208.65 -18.70 facing 0 203 2
execute if score @s galaxy_c matches 16 run tp @s 15.28 208.76 -18.03 facing 0 203 2
execute if score @s galaxy_c matches 17 run tp @s 16.21 208.87 -17.33 facing 0 203 2
execute if score @s galaxy_c matches 18 run tp @s 17.11 208.97 -16.58 facing 0 203 2
execute if score @s galaxy_c matches 19 run tp @s 17.97 209.07 -15.79 facing 0 203 2
execute if score @s galaxy_c matches 20 run tp @s 18.79 209.17 -14.97 facing 0 203 2
execute if score @s galaxy_c matches 21 run tp @s 19.58 209.26 -14.11 facing 0 203 2
execute if score @s galaxy_c matches 22 run tp @s 20.33 209.35 -13.21 facing 0 203 2
execute if score @s galaxy_c matches 23 run tp @s 21.03 209.43 -12.28 facing 0 203 2
execute if score @s galaxy_c matches 24 run tp @s 21.70 209.50 -11.32 facing 0 203 2
execute if score @s galaxy_c matches 25 run tp @s 22.32 209.58 -10.34 facing 0 203 2
execute if score @s galaxy_c matches 26 run tp @s 22.90 209.64 -9.32 facing 0 203 2
execute if score @s galaxy_c matches 27 run tp @s 23.43 209.70 -8.28 facing 0 203 2
execute if score @s galaxy_c matches 28 run tp @s 23.91 209.76 -7.22 facing 0 203 2
execute if score @s galaxy_c matches 29 run tp @s 24.34 209.81 -6.14 facing 0 203 2
execute if score @s galaxy_c matches 30 run tp @s 24.73 209.85 -5.03 facing 0 203 2
execute if score @s galaxy_c matches 31 run tp @s 25.06 209.89 -3.92 facing 0 203 2
execute if score @s galaxy_c matches 32 run tp @s 25.35 209.92 -2.79 facing 0 203 2
execute if score @s galaxy_c matches 33 run tp @s 25.58 209.95 -1.64 facing 0 203 2
execute if score @s galaxy_c matches 34 run tp @s 25.76 209.97 -0.49 facing 0 203 2
execute if score @s galaxy_c matches 35 run tp @s 25.90 209.99 0.67 facing 0 203 2
execute if score @s galaxy_c matches 36 run tp @s 25.97 210.00 1.83 facing 0 203 2
execute if score @s galaxy_c matches 37 run tp @s 26.00 210.00 3.00 facing 0 203 2
execute if score @s galaxy_c matches 38 run tp @s 25.97 210.00 4.17 facing 0 203 2
execute if score @s galaxy_c matches 39 run tp @s 25.90 209.99 5.33 facing 0 203 2
execute if score @s galaxy_c matches 40 run tp @s 25.76 209.97 6.49 facing 0 203 2
execute if score @s galaxy_c matches 41 run tp @s 25.58 209.95 7.64 facing 0 203 2
execute if score @s galaxy_c matches 42 run tp @s 25.35 209.92 8.79 facing 0 203 2
execute if score @s galaxy_c matches 43 run tp @s 25.06 209.89 9.92 facing 0 203 2
execute if score @s galaxy_c matches 44 run tp @s 24.73 209.85 11.03 facing 0 203 2
execute if score @s galaxy_c matches 45 run tp @s 24.34 209.81 12.14 facing 0 203 2
execute if score @s galaxy_c matches 46 run tp @s 23.91 209.76 13.22 facing 0 203 2
execute if score @s galaxy_c matches 47 run tp @s 23.43 209.70 14.28 facing 0 203 2
execute if score @s galaxy_c matches 48 run tp @s 22.90 209.64 15.32 facing 0 203 2
execute if score @s galaxy_c matches 49 run tp @s 22.32 209.58 16.34 facing 0 203 2
execute if score @s galaxy_c matches 50 run tp @s 21.70 209.50 17.32 facing 0 203 2
execute if score @s galaxy_c matches 51 run tp @s 21.03 209.43 18.28 facing 0 203 2
execute if score @s galaxy_c matches 52 run tp @s 20.33 209.35 19.21 facing 0 203 2
execute if score @s galaxy_c matches 53 run tp @s 19.58 209.26 20.11 facing 0 203 2
execute if score @s galaxy_c matches 54 run tp @s 18.79 209.17 20.97 facing 0 203 2
execute if score @s galaxy_c matches 55 run tp @s 17.97 209.07 21.79 facing 0 203 2
execute if score @s galaxy_c matches 56 run tp @s 17.11 208.97 22.58 facing 0 203 2
execute if score @s galaxy_c matches 57 run tp @s 16.21 208.87 23.33 facing 0 203 2
execute if score @s galaxy_c matches 58 run tp @s 15.28 208.76 24.03 facing 0 203 2
execute if score @s galaxy_c matches 59 run tp @s 14.32 208.65 24.70 facing 0 203 2
execute if score @s galaxy_c matches 60 run tp @s 13.34 208.54 25.32 facing 0 203 2
execute if score @s galaxy_c matches 61 run tp @s 12.32 208.42 25.90 facing 0 203 2
execute if score @s galaxy_c matches 62 run tp @s 11.28 208.30 26.43 facing 0 203 2
execute if score @s galaxy_c matches 63 run tp @s 10.22 208.18 26.91 facing 0 203 2
execute if score @s galaxy_c matches 64 run tp @s 9.14 208.05 27.34 facing 0 203 2
execute if score @s galaxy_c matches 65 run tp @s 8.03 207.93 27.73 facing 0 203 2
execute if score @s galaxy_c matches 66 run tp @s 6.92 207.80 28.06 facing 0 203 2
execute if score @s galaxy_c matches 67 run tp @s 5.79 207.67 28.35 facing 0 203 2
execute if score @s galaxy_c matches 68 run tp @s 4.64 207.54 28.58 facing 0 203 2
execute if score @s galaxy_c matches 69 run tp @s 3.49 207.40 28.76 facing 0 203 2
execute if score @s galaxy_c matches 70 run tp @s 2.33 207.27 28.90 facing 0 203 2
execute if score @s galaxy_c matches 71 run tp @s 1.17 207.13 28.97 facing 0 203 2
execute if score @s galaxy_c matches 72 run tp @s 0.00 207.00 29.00 facing 0 203 2
execute if score @s galaxy_c matches 73 run tp @s -1.17 206.87 28.97 facing 0 203 2
execute if score @s galaxy_c matches 74 run tp @s -2.33 206.73 28.90 facing 0 203 2
execute if score @s galaxy_c matches 75 run tp @s -3.49 206.60 28.76 facing 0 203 2
execute if score @s galaxy_c matches 76 run tp @s -4.64 206.46 28.58 facing 0 203 2
execute if score @s galaxy_c matches 77 run tp @s -5.79 206.33 28.35 facing 0 203 2
execute if score @s galaxy_c matches 78 run tp @s -6.92 206.20 28.06 facing 0 203 2
execute if score @s galaxy_c matches 79 run tp @s -8.03 206.07 27.73 facing 0 203 2
execute if score @s galaxy_c matches 80 run tp @s -9.14 205.95 27.34 facing 0 203 2
execute if score @s galaxy_c matches 81 run tp @s -10.22 205.82 26.91 facing 0 203 2
execute if score @s galaxy_c matches 82 run tp @s -11.28 205.70 26.43 facing 0 203 2
execute if score @s galaxy_c matches 83 run tp @s -12.32 205.58 25.90 facing 0 203 2
execute if score @s galaxy_c matches 84 run tp @s -13.34 205.46 25.32 facing 0 203 2
execute if score @s galaxy_c matches 85 run tp @s -14.32 205.35 24.70 facing 0 203 2
execute if score @s galaxy_c matches 86 run tp @s -15.28 205.24 24.03 facing 0 203 2
execute if score @s galaxy_c matches 87 run tp @s -16.21 205.13 23.33 facing 0 203 2
execute if score @s galaxy_c matches 88 run tp @s -17.11 205.03 22.58 facing 0 203 2
execute if score @s galaxy_c matches 89 run tp @s -17.97 204.93 21.79 facing 0 203 2
execute if score @s galaxy_c matches 90 run tp @s -18.79 204.83 20.97 facing 0 203 2
execute if score @s galaxy_c matches 91 run tp @s -19.58 204.74 20.11 facing 0 203 2
execute if score @s galaxy_c matches 92 run tp @s -20.33 204.65 19.21 facing 0 203 2
execute if score @s galaxy_c matches 93 run tp @s -21.03 204.57 18.28 facing 0 203 2
execute if score @s galaxy_c matches 94 run tp @s -21.70 204.50 17.32 facing 0 203 2
execute if score @s galaxy_c matches 95 run tp @s -22.32 204.42 16.34 facing 0 203 2
execute if score @s galaxy_c matches 96 run tp @s -22.90 204.36 15.32 facing 0 203 2
execute if score @s galaxy_c matches 97 run tp @s -23.43 204.30 14.28 facing 0 203 2
execute if score @s galaxy_c matches 98 run tp @s -23.91 204.24 13.22 facing 0 203 2
execute if score @s galaxy_c matches 99 run tp @s -24.34 204.19 12.14 facing 0 203 2
execute if score @s galaxy_c matches 100 run tp @s -24.73 204.15 11.03 facing 0 203 2
execute if score @s galaxy_c matches 101 run tp @s -25.06 204.11 9.92 facing 0 203 2
execute if score @s galaxy_c matches 102 run tp @s -25.35 204.08 8.79 facing 0 203 2
execute if score @s galaxy_c matches 103 run tp @s -25.58 204.05 7.64 facing 0 203 2
execute if score @s galaxy_c matches 104 run tp @s -25.76 204.03 6.49 facing 0 203 2
execute if score @s galaxy_c matches 105 run tp @s -25.90 204.01 5.33 facing 0 203 2
execute if score @s galaxy_c matches 106 run tp @s -25.97 204.00 4.17 facing 0 203 2
execute if score @s galaxy_c matches 107 run tp @s -26.00 204.00 3.00 facing 0 203 2
execute if score @s galaxy_c matches 108 run tp @s -25.97 204.00 1.83 facing 0 203 2
execute if score @s galaxy_c matches 109 run tp @s -25.90 204.01 0.67 facing 0 203 2
execute if score @s galaxy_c matches 110 run tp @s -25.76 204.03 -0.49 facing 0 203 2
execute if score @s galaxy_c matches 111 run tp @s -25.58 204.05 -1.64 facing 0 203 2
execute if score @s galaxy_c matches 112 run tp @s -25.35 204.08 -2.79 facing 0 203 2
execute if score @s galaxy_c matches 113 run tp @s -25.06 204.11 -3.92 facing 0 203 2
execute if score @s galaxy_c matches 114 run tp @s -24.73 204.15 -5.03 facing 0 203 2
execute if score @s galaxy_c matches 115 run tp @s -24.34 204.19 -6.14 facing 0 203 2
execute if score @s galaxy_c matches 116 run tp @s -23.91 204.24 -7.22 facing 0 203 2
execute if score @s galaxy_c matches 117 run tp @s -23.43 204.30 -8.28 facing 0 203 2
execute if score @s galaxy_c matches 118 run tp @s -22.90 204.36 -9.32 facing 0 203 2
execute if score @s galaxy_c matches 119 run tp @s -22.32 204.42 -10.34 facing 0 203 2
execute if score @s galaxy_c matches 120 run tp @s -21.70 204.50 -11.32 facing 0 203 2
execute if score @s galaxy_c matches 121 run tp @s -21.03 204.57 -12.28 facing 0 203 2
execute if score @s galaxy_c matches 122 run tp @s -20.33 204.65 -13.21 facing 0 203 2
execute if score @s galaxy_c matches 123 run tp @s -19.58 204.74 -14.11 facing 0 203 2
execute if score @s galaxy_c matches 124 run tp @s -18.79 204.83 -14.97 facing 0 203 2
execute if score @s galaxy_c matches 125 run tp @s -17.97 204.93 -15.79 facing 0 203 2
execute if score @s galaxy_c matches 126 run tp @s -17.11 205.03 -16.58 facing 0 203 2
execute if score @s galaxy_c matches 127 run tp @s -16.21 205.13 -17.33 facing 0 203 2
execute if score @s galaxy_c matches 128 run tp @s -15.28 205.24 -18.03 facing 0 203 2
execute if score @s galaxy_c matches 129 run tp @s -14.32 205.35 -18.70 facing 0 203 2
execute if score @s galaxy_c matches 130 run tp @s -13.34 205.46 -19.32 facing 0 203 2
execute if score @s galaxy_c matches 131 run tp @s -12.32 205.58 -19.90 facing 0 203 2
execute if score @s galaxy_c matches 132 run tp @s -11.28 205.70 -20.43 facing 0 203 2
execute if score @s galaxy_c matches 133 run tp @s -10.22 205.82 -20.91 facing 0 203 2
execute if score @s galaxy_c matches 134 run tp @s -9.14 205.95 -21.34 facing 0 203 2
execute if score @s galaxy_c matches 135 run tp @s -8.03 206.07 -21.73 facing 0 203 2
execute if score @s galaxy_c matches 136 run tp @s -6.92 206.20 -22.06 facing 0 203 2
execute if score @s galaxy_c matches 137 run tp @s -5.79 206.33 -22.35 facing 0 203 2
execute if score @s galaxy_c matches 138 run tp @s -4.64 206.46 -22.58 facing 0 203 2
execute if score @s galaxy_c matches 139 run tp @s -3.49 206.60 -22.76 facing 0 203 2
execute if score @s galaxy_c matches 140 run tp @s -2.33 206.73 -22.90 facing 0 203 2
execute if score @s galaxy_c matches 141 run tp @s -1.17 206.87 -22.97 facing 0 203 2
execute if score @s galaxy_c matches 2..142 run particle minecraft:flame -2 202 -11 0.25 0.25 0.25 0.03 5 force @s
execute if score @s galaxy_c matches 2..142 run particle minecraft:flame 2 202 -11 0.25 0.25 0.25 0.03 5 force @s
execute if score @s galaxy_c matches 2..142 run particle minecraft:end_rod -2 202 -11 0 0 -1 0.8 0 force @s
execute if score @s galaxy_c matches 2..142 run particle minecraft:end_rod 2 202 -11 0 0 -1 0.8 0 force @s
execute if score @s galaxy_c matches 2..142 run particle minecraft:dust{color:[1.0,0.5,0.1],scale:2.0} 0 202 -11 1.5 0.6 0.3 0 4 force @s
execute if score @s galaxy_c matches 143.. run particle minecraft:end_rod ~1.5 ~-7 ~2.9 0 1 0 2.0 0 force @s
execute if score @s galaxy_c matches 143.. run particle minecraft:end_rod ~5.3 ~-7 ~2.9 0 1 0 2.1 0 force @s
execute if score @s galaxy_c matches 143.. run particle minecraft:end_rod ~-5.7 ~-7 ~-0.4 0 1 0 2.1 0 force @s
execute if score @s galaxy_c matches 143.. run particle minecraft:end_rod ~1.8 ~-7 ~4.8 0 1 0 1.1 0 force @s
execute if score @s galaxy_c matches 143.. run particle minecraft:end_rod ~-0.4 ~-7 ~-3.0 0 1 0 1.7 0 force @s
execute if score @s galaxy_c matches 143.. run particle minecraft:end_rod ~0.9 ~-7 ~-5.8 0 1 0 1.3 0 force @s
execute if score @s galaxy_c matches 143.. run particle minecraft:end_rod ~-2.6 ~-7 ~5.0 0 1 0 1.9 0 force @s
execute if score @s galaxy_c matches 143.. run particle minecraft:end_rod ~-4.1 ~-7 ~3.6 0 1 0 1.2 0 force @s
execute if score @s galaxy_c matches 143.. run particle minecraft:end_rod ~1.4 ~-7 ~-4.5 0 1 0 1.0 0 force @s
execute if score @s galaxy_c matches 143.. run particle minecraft:end_rod ~4.5 ~-7 ~-3.5 0 1 0 1.3 0 force @s
execute if score @s galaxy_c matches 143.. run particle minecraft:end_rod ~5.8 ~-7 ~4.5 0 1 0 1.3 0 force @s
execute if score @s galaxy_c matches 143.. run particle minecraft:end_rod ~5.5 ~-7 ~0.5 0 1 0 1.8 0 force @s
particle minecraft:cloud ~ ~ ~ 2 2 2 0.05 3 normal
execute if score @s galaxy_c matches 3 run title @s times 5 40 10
execute if score @s galaxy_c matches 3 run title @s subtitle {"text":"Brace for Starfall...","color":"yellow"}
execute if score @s galaxy_c matches 3 run title @s title {"text":"JUMP!","color":"gold","bold":true}
execute if score @s galaxy_c matches 50 run title @s times 10 70 15
execute if score @s galaxy_c matches 50 run title @s subtitle {"text":"made by im_foxy","color":"aqua"}
execute if score @s galaxy_c matches 50 run title @s title {"text":"MADE FOR SKYSMP","color":"light_purple","bold":true}
execute if score @s galaxy_c matches 50 run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 1 0.6
execute if score @s galaxy_c matches 143 run title @s times 10 50 15
execute if score @s galaxy_c matches 143 run title @s subtitle {"text":"Land safely...","color":"gray"}
execute if score @s galaxy_c matches 143 run title @s title {"text":"STARFALL AWAITS","color":"dark_purple"}
execute if score @s galaxy_c matches 145.. if entity @s[nbt={OnGround:1b}] run function galaxy:warp/grounded
execute if score @s galaxy_c matches 145.. if entity @s[y=-100,dy=120] run function galaxy:warp/void_rescue
execute if score @s galaxy_c matches 900.. run function galaxy:warp/grounded
