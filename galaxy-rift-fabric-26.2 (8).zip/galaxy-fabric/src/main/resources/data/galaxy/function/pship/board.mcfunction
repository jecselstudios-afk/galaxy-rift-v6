title @s title {"text":"BOARDING","color":"aqua","bold":true}
title @s subtitle {"text":"Returning to the overworld...","color":"gray"}
playsound minecraft:block.end_portal.spawn player @s ~ ~ ~ 3 1
particle minecraft:end_rod ~ ~1 ~ 1 2 1 0.3 80 force
function galaxy:warp/home
